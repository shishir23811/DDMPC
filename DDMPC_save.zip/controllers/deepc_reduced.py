import numpy as np
import cvxpy as cp

from controllers.deepc_vanilla import VanillaDeePC


class ReducedOrderDeePC(VanillaDeePC):
    """SVD-reduced DeePC."""

    def __init__(
        self,
        U_data,
        Y_data,
        energy_ratio=None,
        rank=None,
        **kwargs
    ):
        self.energy_ratio = energy_ratio
        self.rank = rank

        super().__init__(U_data, Y_data, **kwargs)

    def _build_problem(self):

        H_full = np.vstack([self.Hu, self.Hy])

        U_svd, s, Vt = np.linalg.svd(
            H_full,
            full_matrices=False
        )

        if self.rank is not None:

            k = min(self.rank, len(s))

            print(
                f"Reduced-order: k={k}/{len(s)} "
                f"(rank mode)"
            )

        else:

            energy = np.cumsum(s**2) / np.sum(s**2)

            k = (
                np.searchsorted(
                    energy,
                    self.energy_ratio,
                    side="left"
                ) + 1
            )

            k_min = self.n * (self.m + self.p)

            k = max(k, k_min)
            k = min(k, len(s))

            print(
                f"Reduced-order: k={k}/{len(s)} "
                f"({100 * energy[k - 1]:.1f}% energy)"
            )

        self.k_kept = k

        V_r = Vt[:k, :].T

        self.alpha_r = cp.Variable(k)

        self.u_past = cp.Parameter(self.n * self.m)
        self.y_past = cp.Parameter(self.n * self.p)

        self.y_ref = cp.Parameter(
            (self.L, self.p)
        )

        self.u_bar = cp.Variable(
            (self.L, self.m)
        )

        self.y_bar = cp.Variable(
            (self.L, self.p)
        )

        alpha = V_r @ self.alpha_r

        constraints = [

            self.Hu_p @ alpha == self.u_past,
            self.Hy_p @ alpha == self.y_past,

            self.Hu_f @ alpha ==
            cp.reshape(
                self.u_bar,
                (self.L * self.m,),
                order="C"
            ),

            self.Hy_f @ alpha ==
            cp.reshape(
                self.y_bar,
                (self.L * self.p,),
                order="C"
            )
        ]

        cost = (
            cp.sum_squares(
                self.y_bar - self.y_ref
            )
            +
            1e-2 *
            cp.sum_squares(self.u_bar)
            +
            self.lam *
            cp.sum_squares(alpha)
        )

        self.prob = cp.Problem(
            cp.Minimize(cost),
            constraints
        )