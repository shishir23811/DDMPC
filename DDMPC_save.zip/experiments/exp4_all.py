import os
import numpy as np
import matplotlib.pyplot as plt

from controllers.deepc_vanilla import VanillaDeePC
from controllers.deepc_online import OnlineDeePC
from controllers.deepc_reduced import ReducedOrderDeePC

from sim.closed_loop_driver import (
    run_closed_loop,
    run_closed_loop_drift
)

from sim.references import (
    straight_line,
    circle,
    lane_change,
    double_lane_change,
    figure_eight
)

# =====================================================
# Configuration
# =====================================================

L = 24
n = 6
lam = 1e-3

REDUCED_RANK = 100

T_NORMAL = 32.0
T_DRIFT = 32.0

os.makedirs("results", exist_ok=True)

# =====================================================
# Load data
# =====================================================

data = np.load("data/open_loop.npz")

# =====================================================
# References
# =====================================================

references = {
    # "straight_line": straight_line,
    # "circle": circle,
    # "lane_change": lane_change,
    "double_lane_change": double_lane_change,
    "figure_eight": figure_eight,
}

# =====================================================
# Controller factory
# =====================================================

def build_controllers():

    vanilla = VanillaDeePC(
        data["U"],
        data["Y"],
        L=L,
        n=n,
        lam=lam
    )

    online = OnlineDeePC(
        data["U"],
        data["Y"],
        L=L,
        n=n,
        lam=lam,
        update_every=10
    )

    reduced = ReducedOrderDeePC(
        data["U"],
        data["Y"],
        rank=REDUCED_RANK,
        L=L,
        n=n,
        lam=lam
    )

    return vanilla, online, reduced

# =====================================================
# Plot helper
# =====================================================

def make_plot(
    filename,
    title,
    ref_log,
    vanilla_log,
    online_log,
    reduced_log
):

    plt.figure(figsize=(9, 6))

    plt.plot(
        ref_log["ref"][:, 0],
        ref_log["ref"][:, 1],
        "k--",
        linewidth=2,
        label="Reference"
    )

    plt.plot(
        vanilla_log["y"][:, 0],
        vanilla_log["y"][:, 1],
        "r",
        label="Vanilla DeePC"
    )

    plt.plot(
        online_log["y"][:, 0],
        online_log["y"][:, 1],
        "b",
        label="Online DeePC"
    )

    plt.plot(
        reduced_log["y"][:, 0],
        reduced_log["y"][:, 1],
        "g",
        label="Reduced DeePC"
    )

    plt.xlabel("X (m)")
    plt.ylabel("Y (m)")

    plt.title(title)

    plt.axis("equal")
    plt.grid(True)
    plt.legend()

    plt.tight_layout()

    plt.savefig(
        os.path.join("results", filename),
        dpi=150
    )

    plt.close()

# =====================================================
# Run experiments
# =====================================================

for ref_name, ref_func in references.items():

    print(f"\n{'='*60}")
    print(f"Reference: {ref_name}")
    print(f"{'='*60}")

    # -------------------------------------------------
    # NO DRIFT
    # -------------------------------------------------

    print("Running no-drift experiment...")

    vanilla, online, reduced = build_controllers()

    log_vanilla = run_closed_loop(
        vanilla,
        ref_func,
        T=T_NORMAL,
        noise=False,
        n=n,
        L=L
    )

    log_online = run_closed_loop(
        online,
        ref_func,
        T=T_NORMAL,
        noise=False,
        n=n,
        L=L
    )

    log_reduced = run_closed_loop(
        reduced,
        ref_func,
        T=T_NORMAL,
        noise=False,
        n=n,
        L=L
    )

    make_plot(
        f"{ref_name}_no_drift.png",
        f"{ref_name.replace('_',' ').title()} (No Drift)",
        log_vanilla,
        log_vanilla,
        log_online,
        log_reduced
    )

    print(
        f"Saved results/{ref_name}_no_drift.png"
    )

    # -------------------------------------------------
    # DRIFT
    # -------------------------------------------------

    print("Running drift experiment...")

    vanilla, online, reduced = build_controllers()

    log_vanilla = run_closed_loop_drift(
        vanilla,
        ref_func,
        T=T_DRIFT,
        n=n,
        L=L
    )

    log_online = run_closed_loop_drift(
        online,
        ref_func,
        T=T_DRIFT,
        n=n,
        L=L
    )

    log_reduced = run_closed_loop_drift(
        reduced,
        ref_func,
        T=T_DRIFT,
        n=n,
        L=L
    )

    make_plot(
        f"{ref_name}_drift.png",
        f"{ref_name.replace('_',' ').title()} (Drift)",
        log_vanilla,
        log_vanilla,
        log_online,
        log_reduced
    )

    print(
        f"Saved results/{ref_name}_drift.png"
    )